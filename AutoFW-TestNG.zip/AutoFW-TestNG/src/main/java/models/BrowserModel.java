package models;

public class BrowserModel {
    public static final String FIREFOX = "firefox";
    public static final String GOOGLE_CHROME = "chrome";
    public static final String INTERNET_EXPLORER = "ie";
}
